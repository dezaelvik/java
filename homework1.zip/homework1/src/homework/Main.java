package homework;

public class Main {

    public static void main (String[] args) {


               System.out.println("дз 1.");
                boolean b = false;
               byte bt = 0;
                char c = 'x';
               short n = 123;
                int i = 1234;
               long z = 12345L;
               float f = 12345.0f;
               double v = 123.456;
              System.out.println("Значение для типа boolean = " + b);
               System.out.println("Значение для типа byte = " + bt);
              System.out.println("Значение для типа char = [" + c + "]");
              System.out.println("Значение для типа short = " + n);
               System.out.println("Значение для типа int = " + i);
              System.out.println("Значение для типа long = " + z);
              System.out.println("Значение для типа float = " + f);System.out.println("Значение для типа double = " + v);
           }
            static double second (double a, double b, double c, double d) {
               System.out.println("дз 2.");
               return a * (b + (c / d)); }
           static boolean third (int a, int b) {
               System.out.println("дз 3.");
                int sum = a + b;
                if (sum > 10 && sum < 20) return true;
               else return false;
        }
           static void fourth (int a) {
               System.out.println("дз 4.");
                if (a >= 0) System.out.println("Число " + a + "положительное");
                else System.out.println("Число " + a + " отрицательное");
           }
            static boolean Fifth (int a) {
          System.out.println("дз 5.");
               if (a < 0) return true;
               return false;
           }
           static void Sixth (String name) {
        System.out.println("дз 6.");
               System.out.println("Привет, " + name + "!");
       }

       }
class Mai {

    public static void main(String[] args) {
        int r = 10;
        int t = 5;
        int s = 6;
        int p = 2;
        int l = r * (t + (s / p));
        System.out.println(l);


        int x = sum(5, 6, 4, 2);
        int y = sum(5, 8, 4, 2);
        System.out.println(x);
        System.out.println(y);
    }

    static int sum(int a, int b, int c, int d) {

        return a * (b + (c / d)); //на этом моменте поняла, что сделала сложнее, и дальше программа будет длиннее.
    }
}